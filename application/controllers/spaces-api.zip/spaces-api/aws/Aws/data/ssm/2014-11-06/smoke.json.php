<?php
// This file was auto-generated from sdk-root/src/data/ssm/2014-11-06/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListDocuments', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetDocument', 'input' => [ 'Name' => '\'fake-name\'', ], 'errorExpectedFromService' => true, ], ],];
